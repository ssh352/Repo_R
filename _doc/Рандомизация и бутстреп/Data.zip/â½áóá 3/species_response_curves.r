#JUICE-R JUICE.table JUICE.short.head JUICE.species.data R.exe

# the whole srcjuice function
count.GAM <-                                            
function (methods.incl.GAM, part.species, gr, axx, ampl, proportion, auc)
   {
   gam.0<-gam(part.species~1, family='binomial')
   if (methods.incl.GAM==1)
   {
    gam.3<-gam(part.species~s(gr,k=3), family='binomial')
    gam.4<-gam(part.species~s(gr,k=4), family='binomial')
    gam.5<-gam(part.species~s(gr,k=5), family='binomial')
    allAIC <- c(extractAIC (gam.3)[2], extractAIC (gam.4)[2], extractAIC (gam.5)[2])
    switch (c(1,2,3)[allAIC==min(allAIC)],
      {gam.GAM <- gam.3; GAM.deg <- 3},
      {gam.GAM <- gam.4; GAM.deg <- 4},
      {gam.GAM <- gam.5; GAM.deg <- 5})
    }
    
    if (methods.incl.GAM > 10)
    {
    switch (methods.incl.GAM-12,
      {gam.GAM<-gam(part.species~s(gr,k=3), family='binomial'); GAM.deg<-3},
      {gam.GAM<-gam(part.species~s(gr,k=4), family='binomial'); GAM.deg<-4},
      {gam.GAM<-gam(part.species~s(gr,k=5), family='binomial'); GAM.deg<-5})
    }
    fit.GAM<-predict(gam.GAM, list(gr=axx), type='response')
    amplitude.range <- interval.range.prob (fit.GAM, axx, ampl, proportion, auc)
    print.GAM<-c(axx[fit.GAM==max(fit.GAM)][1], amplitude.range, max(fit.GAM)[1], diff(amplitude.range), GAM.deg, local.min.max (fit.GAM))
    list (fit.GAM, print.GAM, GAM.deg)
  }

count.GAUS <-
function (part.species, gr, axx, ampl, proportion, auc)
  {
    glm.gaus<-glm(part.species~gr+I(gr^2), family=poisson)
    p.glm.gaus<-coef(glm.gaus)
    fit.GAUS<-GAUS.fun(p.glm.gaus, axx)
    amplitude.range <- interval.range.prob (fit.GAUS, axx, ampl, proportion, auc)
    print.GAUS<-c(axx[fit.GAUS==max(fit.GAUS)][1], amplitude.range, max(fit.GAUS)[1], diff(amplitude.range), "", local.min.max (fit.GAUS))
    list(fit.GAUS, print.GAUS)
   }

count.GLM <-
function (methods.incl.GLM, part.species, gr, axx, ampl, proportion, auc)
  {
  if (methods.incl.GLM==1)
   {glm.1<-glm(part.species~poly(gr,1), family='binomial')
    glm.2<-glm(part.species~poly(gr,2), family='binomial')
    glm.3<-glm(part.species~poly(gr,3), family='binomial')
    allAIC <- c(extractAIC (glm.1)[2], extractAIC (glm.2)[2], extractAIC (glm.3)[2])
    switch (c(1,2,3)[allAIC==min(allAIC)],
      {glm.GLM <- glm.1; GLM.deg <- 1},
      {glm.GLM <- glm.2; GLM.deg <- 2},
      {glm.GLM <- glm.3; GLM.deg <- 3})
    }
    switch (methods.incl.GLM-10,
      {glm.GLM<-glm(part.species~poly(gr,1), family='binomial'); GLM.deg<-1},
      {glm.GLM<-glm(part.species~poly(gr,2), family='binomial'); GLM.deg<-2},
      {glm.GLM<-glm(part.species~poly(gr,3), family='binomial'); GLM.deg<-3})
    
    fit.GLM<-predict(glm.GLM, list(gr=axx), type='response')
    amplitude.range <- interval.range.prob (fit.GLM, axx, ampl, proportion, auc)
    print.GLM<-c(axx[fit.GLM==max(fit.GLM)][1], amplitude.range, max(fit.GLM)[1], diff(amplitude.range), GLM.deg, local.min.max (fit.GLM))
    list (fit.GLM, print.GLM, GLM.deg)
    }

count.HOF <-
function (methods.incl.HOF, part.species, gr, axx, ampl, proportion, auc)
    {
  model.test.HOF <- 'AIC'
  old.Oksanen <- FALSE
  pick.model.second.done <- FALSE
  HOF.model<-HOF(part.species, gr, M=1, family=binomial)
  if (methods.incl.HOF==1)
    {the.best.HOF<-pick.model(HOF.model, test=model.test.HOF)
     #correction for strange shapes:
     if (the.best.HOF=="III")
       {
        if(abs(HOF.model$model$III$estimate[1])>100 | abs(HOF.model$model$III$estimate[2])>100 | abs(HOF.model$model$III$estimate[3])>100)
           {the.best.HOF <- pick.model.second (HOF.model, test=model.test.HOF); pick.model.second.done <- TRUE}  
       }
       
     if (the.best.HOF=="V")
       {
         if(abs(HOF.model$model$V$estimate[1])>100 | abs(HOF.model$model$V$estimate[2])>100 | abs(HOF.model$model$V$estimate[3])>100 | abs(HOF.model$model$V$estimate[4])>100)
            {p<-HOF.start(gr, part.species, model=5)
             sol.HOF <- nlm(HOF.HOF, p, x=gr, y=part.species, model=5)
             if(abs(sol.HOF$estimate[1])>100 | abs(sol.HOF$estimate[2])>100 | abs(sol.HOF$estimate[3])>100 | abs(sol.HOF$estimate[4])>100 )
                 {
                 if (pick.model.second.done) the.best.HOF<-pick.model.third (HOF.model, test=model.test.HOF) else the.best.HOF<-pick.model.second (HOF.model, test=model.test.HOF)
                 if (the.best.HOF=='III') 
                   {
                   if(abs(HOF.model$model$III$estimate[1])>100 | abs(HOF.model$model$III$estimate[2])>100 | abs(HOF.model$model$III$estimate[3])>100)
                     {the.best.HOF <- pick.model.third (HOF.model, test=model.test.HOF)}
                   }
                 } 
                 else { old.Oksanen <- TRUE }
             }
       }
     
      }
      else { switch(methods.incl.HOF-10,
                the.best.HOF<-"I",
                the.best.HOF<-"II",
                the.best.HOF<-"III",
                the.best.HOF<-"IV",
                the.best.HOF<-"V") 
            }
    if (old.Oksanen==TRUE) {fit.HOF<-HOF.fun (sol.HOF$estimate, model=5, x=axx); the.best.HOF <- "V";}
      else 
      {fit.HOF<-predict.HOF(HOF.model, axx, model=the.best.HOF, M=1)}

# tohle vyresit nejak jinak:
    if (old.Oksanen==TRUE) fit.HOF.orig.val<-HOF.fun (sol.HOF$estimate, model=5, x=gr) else fit.HOF.orig.val<-predict.HOF(HOF.model, gr, model=the.best.HOF, M=1)
    assign ('fit.HOF.orig.val', fit.HOF.orig.val, env = .GlobalEnv)
    
    maximum.fit<-mean(range(axx[fit.HOF==max(fit.HOF)]))
    amplitude.range <- interval.range.prob (fit.HOF, axx, ampl, proportion, auc)
    print.HOF.table<-c(maximum.fit, amplitude.range, max(fit.HOF)[1], diff(amplitude.range), the.best.HOF, local.min.max (fit.HOF))
  list (fit.HOF, print.HOF.table, the.best.HOF)
  }

GAUS.fun <-
function(p, x)
{
fv <- exp(p[1] + p[2]*x + p[3]*(x^2))
fv
}

GAUS.GAUS <-
function(p, x, y)
{
fv <- GAUS.fun(p,x)
-sum(dbinom(y,1,fv, log=TRUE))
}

HOF.fun <-
function(p, model, x, M=1)
{
x <- scale01(x)
switch(model,
fv <- rep(M/(1+exp(p[1])), length(x)),
fv <- M/(1+exp(p[1]+p[2]*x)),
fv <- M/(1+exp(p[1]+p[2]*x))/(1+exp(p[3])),
fv <- M/(1+exp(p[1]+p[2]*x))/(1+exp(p[3]-p[2]*x)),
fv <- M/(1+exp(p[1]+p[2]*x))/(1+exp(p[3]-p[4]*x))
       )
fv
}

HOF.HOF <-
function (x, y, p, model, M=1)
{
fv <- HOF.fun (p, model, x, M=M)
-sum(dbinom(y, M, fv, log=TRUE))
}

HOF.start <-
function (x, y, model=5)
{
x <- scale01(x)
if (model >= 4) {
k <- coef (glm(y~x + I(x^2), family=binomial))
u <- -k[2]/2/k[3]
h <- plogis(k[1] - k[2]^2/4/k[3])
if (h==1) {h<-0.999}
r <- log(1/h*(-2*h+2*sqrt(h))/2)
b <- 5.07 - 0.227*k[3]
a <- -b*u+r
c <- b*u+r
}
else {
k <- coef(glm(y~x, family=binomial))
a <- -k[1]
b <- -k[2]
c <- 0
}
switch(model,
p <- c(a=a),
p <- c(a=a, b=b),
p <- c(a=a, b=b, c=c),
p <- c(a=a, b=b, c=c),
p <- c(a=a, b=b, c=c, d=b)
)
p
}

interval.range.prob <-
function (fit, axx, ampl, proportion, auc)
  {
   if (ampl == 'ratio') 
      {
      amplitude.prob <- max(fit)*proportion
      amplitude.range <- range(axx[fit >= amplitude.prob])
      }
   if (ampl == 'area')
     if (diff(range(fit))>0)
     {
      whole.auc <- sum (fit)
      part.auc <- whole.auc * (auc/100)
      for (l in seq(max(fit)[1], min(fit)[1], length = 100))
        {
         if (sum (fit[fit >= l]) >= part.auc) {last.l <- l; break ()}
        } 
      amplitude.prob <- last.l
      amplitude.range <- range(axx[fit >= amplitude.prob])
      } else 
      {
      amplitude.range <- c(min(axx)+(((max(axx)-min(axx))/100)*((100-auc)/2)), max(axx)-(((max(axx)-min(axx))/100)*((100-auc)/2))) 
      }
  if (ampl == 'kappa')
      {
      species.pa <- read.csv2 ('real_species_pa_data.csv')[,2]
      gr <- read.csv2 ('gr.csv')[,2]      
      ###the following objects have to be created before using the script:
### y: vector of occurence data used for model calibration (absence: 0; presence: 1)
### y.pred: vector of predicted probabilities for each case of the calibration data; can be obtained from the HOF-model object created by gravy (fitted values)

y <- species.pa
y.pred <- fit.HOF.orig.val

if (diff(range(fit))>0)
      {

###create initial values
###minimum gradient (here: pH) value
x.min<-min (axx)
###maximum gradient (here: pH) value
x.max<-max (axx)
###create gradient vector from x.min to x.max with increment 0.01
pH.values<-axx
###create vector for probability thresholds from 0 to 1 with increment 0.01
if (max (fit) >= 0.15) thresholds<-seq(0,1,0.01) else thresholds <- seq (0,1, 0.001)


#calculate predicted probability for each pH step from the HOF-model
#ph.pred<-predict.HOF(temp,pH.values,"I")
ph.pred <- fit

###calculate kappa value for each threshold (see function kappa.eval below)
pcrit <- vector ('numeric', length (thresholds))
for (j in 1:length(thresholds)){
     pcrit[j]<-kappa.eval(y,y.pred,thresholds[j])
}
###calculate maximum kappa value
kappa.max<-max(pcrit)
###calculate probability threshold where kappa is maximized
p.kappa<-min(thresholds[pcrit>=kappa.max])
###calculate lower amplitude limit
ampl.lower<-as.double(min(pH.values[ph.pred>=p.kappa]))
###calculate upper amplitude limit
ampl.upper<-as.double(max(pH.values[ph.pred>=p.kappa]))
###

    
      amplitude.prob <- p.kappa
      amplitude.range <- c(ampl.lower, ampl.upper)

## tohle pozdejc odstranit!!!      
      print (amplitude.prob)
      print (kappa.max)
#      print (pcrit); write.csv2 (pcrit, 'pcrit.csv')
######
        } else {amplitude.range <- c(min(axx), max (axx)) ; amplitude.prob <- min (fit)}
      }  
      amplitude.range
   }

local.min.max <-
function (data)
  {
  if (all(diff(data)==0)) delka <- 0 else
  {diff.data <- diff(data)[diff(data)!=0]
  inflex.data <- NULL
  for (i in seq (1, length(diff.data)-1)) inflex.data[i] <- diff.data[i]*diff.data[i+1]
  delka <- length(inflex.data[inflex.data<0])
  }
  delka
  }

pick.model.second <-
function (obj, level = 0.95, test = c("F", "Chisq", "AIC", "BIC"), 
    ...) 
{
    test <- match.arg(test)
    if (test == "F") {
        res.dv <- deviance(obj, "V")
        res.df <- df.residual(obj, "V")
        denom <- res.dv/res.df
        crit <- qf(level, 1, res.dv)
    }
    if (test == "Chisq") {
        crit <- qchisq(level, 1)
        denom <- 1
    }
    if (test == "Chisq" || test == "F") {
        dev <- deviance(obj)
        j <- which.min(dev[2:3]) + 1
        stat <- diff(dev[c(1, j, 4:5)])
        model <- "V"
        for (i in 1:3) {
            if (stat[i]/denom > crit) 
                break
            model <- names(stat)[i]
        }
    }
    else {
        k <- if (test == "BIC") 
            log(obj$nobs)
        else 2
        ic <- 2 * logLik(obj) + k * sapply(obj$models, function(x) length(x$estimate))
        ic[which.min(ic)] <- NA
        model <- (names(ic))[which.min(ic)]
    }
    model
}

pick.model.third <-
function (obj, level = 0.95, test = c("F", "Chisq", "AIC", "BIC"), 
    ...) 
{
    test <- match.arg(test)
    if (test == "F") {
        res.dv <- deviance(obj, "V")
        res.df <- df.residual(obj, "V")
        denom <- res.dv/res.df
        crit <- qf(level, 1, res.dv)
    }
    if (test == "Chisq") {
        crit <- qchisq(level, 1)
        denom <- 1
    }
    if (test == "Chisq" || test == "F") {
        dev <- deviance(obj)
        j <- which.min(dev[2:3]) + 1
        stat <- diff(dev[c(1, j, 4:5)])
        model <- "V"
        for (i in 1:3) {
            if (stat[i]/denom > crit) 
                break
            model <- names(stat)[i]
        }
    }
    else {
        k <- if (test == "BIC") 
            log(obj$nobs)
        else 2
        ic <- 2 * logLik(obj) + k * sapply(obj$models, function(x) length(x$estimate))
        ic[which.min(ic)] <- NA
        ic[which.min(ic)] <- NA
        model <- (names(ic))[which.min(ic)]
    }
    model
}

predict.HOF <-
function (object, newdata, model, M, ...) 
{
    p <- coef(object, model, ...)
    xrange <- object$range
    if (missing(newdata)) 
        x <- object$x
    else x <- newdata
    fv <- HOF1(x, model, p, M, xrange)
    fv
}

print.result <-
function(input.data, type.of.mode, print.graph=TRUE, save.table, GAUS, GLM, GAM, HOF, trans.sp=0, trans.gr=0, ampl='area', proportion=0.5, auc=80, save.graph.data = TRUE, draw.interval = TRUE, bw = TRUE, alert.bimodality = TRUE)
{          
#input.data.temp <- read.table("input_data_SRC.txt", sep=";", skip=1)
#input.data <- t (input.data.temp[,-1])
#colnames (input.data) <- input.data.temp[,1]  # this is the last fix to allow the species of the same name to be selected

#  input.data <- data.frame(input.data, check.names=FALSE)
#  input.data <- input.data[is.na(input.data[,1]) == FALSE,]

  gr<-input.data[,1]
  gr.name<-names(input.data)[1]
  switch(trans.gr+1,
    gr<-gr,           #trans.gr = 0: no transformation  
    gr<-log(gr+1),    #trans.gr = 1: ln transformation
    gr<-sqrt(gr)      #trans.gr = 2: sqrt transformation
    )
  
  if (type.of.mode < 3)
  {
  species<-as.matrix(input.data[,(2:ncol(input.data))])
  spec.name<-names(input.data[2:ncol(input.data)])
  }
  
  no.species<-ncol(input.data)-1
  
  methods.incl<-list(GAUS=GAUS, GLM=GLM, GAM=GAM, HOF=HOF)
  
  switch(type.of.mode,
    process1(species, gr, spec.name, gr.name, print.graph, save.table, methods.incl, trans.gr, ampl, proportion, auc, save.graph.data, draw.interval,  bw, alert.bimodality),
    process2(species, gr, spec.name, gr.name, print.graph, save.table, methods.incl, trans.gr, ampl, proportion, auc, save.graph.data, draw.interval, bw, alert.bimodality),
    { # calculation for all species, previously not in the script (process3):
    table.result <- NULL
    input.data.all <- as.data.frame (cbind (JUICE.short.head$Short_Head, JUICE.table))
    win.pb <- winProgressBar (title = 'Calculation progress', label = paste ('Species no. ', 1), min = 1, max = dim (JUICE.table)[2], initial = 0, width = 300) 
    for (sp in seq (2, dim (JUICE.table)[2]+1)) {table.result <- rbind (table.result, process3(input.data.all[,sp], gr, names (input.data.all)[sp], gr.name, print.graph, save.table, methods.incl, trans.gr, ampl, proportion, auc, save.graph.data, draw.interval,  bw, alert.bimodality)); setWinProgressBar (win.pb, sp, label = paste ('Species no. ', sp-1))}
    write.table (table.result, 'result_table.csv', dec = '.', sep = ';', col.names = NA, row.names = TRUE, qmethod = 'double')
  close (win.pb)
  spd <- matrix (unlist (strsplit (as.character(rownames (table.result)), split = '_')), ncol = 2, byrow = T)
  spaces <- 50-unlist (lapply ((strsplit(spd[,1], split = '' )), length))
  rep.spaces <- function (times) paste (rep (' ', times), collapse = '')
  write.table (file = 'import_species_data_to_JUICE.txt', paste (spd[,1], unlist (apply (as.matrix (spaces), 1, rep.spaces)), table.result[,as.numeric (tclvalue (tk.save.sp.data))+1]), quote = F, row.names = F, col.names = F)
  tkmessageBox (type = 'ok', message = paste ('Result files were saved into', getwd (), '\n\nYou can use the file import_species_data_to_JUICE.txt to import the species data directly to JUICE (File > Import > Species Data).', if (length (unique (spd[,1])) < length (spd[,1])) '\n\nNote that in your file some species occur more than once - may be they occur simultaneously in several vegetation layers? While importing species data, JUICE cannot distinguish between species in different layers!' ))
    }
    )
}

process1 <-
function(species, gr, spec.name, gr.name, print.graph, save.table, methods.incl, trans.gr, ampl, proportion, auc, save.graph.data, draw.interval, bw, alert.bimodality)
{
axx<-seq(range(gr)[1], range(gr)[2], len=1001)

print.GAUS<-NULL
print.GLM<-NULL
print.GAM<-NULL
print.HOF.table<-NULL

if (save.table)
{
table.no.col<-(trans.to.binom(methods.incl$GAUS) + trans.to.binom(methods.incl$GLM) + trans.to.binom(methods.incl$GAM) + trans.to.binom(methods.incl$HOF))*7
table.header<-NULL
    if (methods.incl$GAUS==1){table.header<-append(table.header, c("GAUS - optimum", "GAUS - min", "GAUS - max", "GAUS - prob-optimum", "GAUS - interval", "", "GAUS - bimodality"))}
    if (methods.incl$GLM>=1){table.header<-append(table.header, c("GLM - optimum", "GLM - min", "GLM - max", "GLM - prob-optimum", "GLM - interval", "GLM - model", "GLM - bimodality"))}
    if (methods.incl$GAM>=1){table.header<-append(table.header, c("GAM - optimum", "GAM - min", "GAM - max", "GAM - prob-optimum", "GAM - interval", "GAM - model", "GAM - bimodality"))}
    if (methods.incl$HOF>=1){table.header<-append(table.header, c("HOF - optimum", "HOF - min", "HOF - max", "HOF - prob-optimum", "HOF - interval", "HOF - model", "HOF - bimodality"))}
table.result<-matrix(NA, nrow=dim (species)[2], ncol=table.no.col, dimnames=list(spec.name, table.header), byrow=TRUE)
}    

if (as.numeric (tclvalue (tk.save.as.pdf))) pdf ()

for (i in seq (1, dim (species)[2])) 
{
table.line<-NULL
part.species <- trans.to.binom(species[,i])

if (methods.incl$GAUS==1)
    {
    result.GAUS <- count.GAUS (part.species, gr, axx, ampl, proportion, auc)
    }
if (methods.incl$GLM>=1)
    {
  result.GLM <- count.GLM (methods.incl.GLM=methods.incl$GLM, part.species, gr, axx, ampl, proportion, auc)
    }
if (methods.incl$GAM>=1)
   {
  result.GAM <- count.GAM (methods.incl.GAM=methods.incl$GAM, part.species, gr, axx, ampl, proportion, auc)
   }
if (methods.incl$HOF>=1)
    {
  result.HOF <- count.HOF (methods.incl.HOF=methods.incl$HOF, part.species, gr, axx, ampl, proportion, auc)
      }

if (save.table)
   {
    if (methods.incl$GAUS==1) {table.line<-append(table.line, c(result.GAUS[[2]]))}
    if (methods.incl$GLM>=1)  {table.line<-append(table.line, c(result.GLM[[2]]))}
    if (methods.incl$GAM>=1)  {table.line<-append(table.line, c(result.GAM[[2]]))}
    if (methods.incl$HOF>=1)  {table.line<-append(table.line, c(result.HOF[[2]]))}
    table.result[i,] <- table.line
  } 

if (save.graph.data == TRUE)
  {
  table.no.col <- trans.to.binom(methods.incl$GAUS) + trans.to.binom(methods.incl$GLM) + trans.to.binom(methods.incl$GAM) + trans.to.binom(methods.incl$HOF)
  
  graph.data.matrix <- axx
  gdm.header <- gr.name
  if (methods.incl$GAUS==1){graph.data.matrix <- append (graph.data.matrix, result.GAUS[[1]]); gdm.header <- append (gdm.header, paste ('GAUS -', spec.name[1]))}
  if (methods.incl$GLM>=1) {graph.data.matrix <- append (graph.data.matrix, result.GLM[[1]]); gdm.header <- append (gdm.header, paste ('GLM -', spec.name[1]))}
  if (methods.incl$GAM>=1) {graph.data.matrix <- append (graph.data.matrix, result.GAM[[1]]); gdm.header <- append (gdm.header, paste ('GAM -', spec.name[1]))}
  if (methods.incl$HOF>=1) {graph.data.matrix <- append (graph.data.matrix, result.HOF[[1]]); gdm.header <- append (gdm.header, paste ('HOF -', spec.name[1]))}
  graph.data.matrix <- matrix (graph.data.matrix, ncol = table.no.col+1, nrow = 1001, dimnames = list(seq(1,1001), gdm.header))  
  write.table (graph.data.matrix, 'graph_data.csv', dec = '.', sep = ';', col.names = TRUE, row.names = FALSE, qmethod = 'double')
  }  
    
if (print.graph==TRUE)
    {
    switch (trans.gr+1,
      gr.label<-gr.name,
      gr.label<-paste(c("log (", gr.name, "+1)"), collapse=""),
      gr.label<-paste(c("sqrt (", gr.name, ")"), collapse="")
            )
    no.of.methods<-trans.to.binom(methods.incl$GAUS) + trans.to.binom(methods.incl$GLM) + trans.to.binom(methods.incl$GAM) + trans.to.binom(methods.incl$HOF)
    spec.name.graph<-spec.name[i]
    fity <- NULL
    fity.ampl <- NULL
    cat <- NULL
    cat.ampl <- NULL
    n.axx.ampl <- NULL
    y.labels <- NULL
    
    if (methods.incl$GAUS==1){fity<-append(fity, remove.bellow.zerro(result.GAUS[[1]])); cat<-append(cat, rep(paste(c("GAUS", if(result.GAUS[[2]][7]>1 & alert.bimodality) "**"), collapse = " "), 1001))}
    if (methods.incl$GLM>=1){fity<-append(fity, remove.bellow.zerro(result.GLM[[1]]));   cat<-append(cat, rep(paste(c("GLM", result.GLM[[3]], if(result.GLM[[2]][7]>1 & alert.bimodality) "**"), collapse=" "), 1001))}
    if (methods.incl$GAM>=1){fity<-append(fity, remove.bellow.zerro(result.GAM[[1]]));   cat<-append(cat, rep(paste(c("GAM", result.GAM[[3]], if(result.GAM[[2]][7]>1 & alert.bimodality) "**"), collapse=" "), 1001))}
    if (methods.incl$HOF>=1){fity<-append(fity, remove.bellow.zerro(result.HOF[[1]]));   cat<-append(cat, rep(paste(c("HOF", result.HOF[[3]], if(result.HOF[[2]][7]>1 & alert.bimodality) "**"), collapse=" "), 1001))}
    n.axx<-rep(axx, no.of.methods)
    if (draw.interval)
       {
       opt.ampl.x <- NULL
       opt.ampl.y <- NULL
       y.values.ampl <- NULL
       y.labels.ampl <- no.of.methods
       if (methods.incl$GAUS==1)
        {fity.ampl<-append(fity.ampl, result.GAUS[[1]][(axx>=result.GAUS[[2]][2])&(axx<=result.GAUS[[2]][3])]); n.axx.ampl <- append (n.axx.ampl, axx[(axx>=result.GAUS[[2]][2])&(axx<=result.GAUS[[2]][3])]); y.values.ampl <- append (y.values.ampl, rep (y.labels.ampl, sum ((axx>=result.GAUS[[2]][2])&(axx<=result.GAUS[[2]][3])))); opt.ampl.y <- append (opt.ampl.y, y.labels.ampl); opt.ampl.x <- append(opt.ampl.x, result.GAUS[[2]][1]); y.labels.ampl <- y.labels.ampl-1; cat.ampl<-append(cat.ampl, rep(paste(c("GAUS", if(result.GAUS[[2]][7]>1 & alert.bimodality) "**"), collapse=" "), sum((axx>=result.GAUS[[2]][2])&(axx<=result.GAUS[[2]][3])))); y.labels<-append(y.labels, paste(c("GAUS", if(result.GAUS[[2]][7]>1 & alert.bimodality) "**"), collapse = " "))}
       if (methods.incl$GLM>=1)
        {fity.ampl<-append(fity.ampl, result.GLM [[1]][(axx>=result.GLM [[2]][2])&(axx<=result.GLM [[2]][3])]); n.axx.ampl <- append (n.axx.ampl, axx[(axx>=result.GLM [[2]][2])&(axx<=result.GLM [[2]][3])]); y.values.ampl <- append (y.values.ampl, rep (y.labels.ampl, sum ((axx>=result.GLM [[2]][2])&(axx<=result.GLM [[2]][3])))); opt.ampl.y <- append (opt.ampl.y, y.labels.ampl); opt.ampl.x <- append(opt.ampl.x, result.GLM[[2]][1]);  y.labels.ampl <- y.labels.ampl-1; cat.ampl<-append(cat.ampl, rep(paste(c("GLM", result.GLM[[3]], if(result.GLM[[2]][7]>1 & alert.bimodality) "**"), collapse=" "), sum ((axx>=result.GLM[[2]][2])&(axx<=result.GLM[[2]][3])))); y.labels<-append(y.labels, paste(c("GLM", result.GLM[[3]], if(result.GLM[[2]][7]>1 & alert.bimodality)"**"), collapse=" "))}
       if (methods.incl$GAM>=1)
        {fity.ampl<-append(fity.ampl, result.GAM [[1]][(axx>=result.GAM [[2]][2])&(axx<=result.GAM [[2]][3])]); n.axx.ampl <- append (n.axx.ampl, axx[(axx>=result.GAM [[2]][2])&(axx<=result.GAM [[2]][3])]); y.values.ampl <- append (y.values.ampl, rep (y.labels.ampl, sum ((axx>=result.GAM [[2]][2])&(axx<=result.GAM [[2]][3])))); opt.ampl.y <- append (opt.ampl.y, y.labels.ampl); opt.ampl.x <- append(opt.ampl.x, result.GAM[[2]][1]);  y.labels.ampl <- y.labels.ampl-1; cat.ampl<-append(cat.ampl, rep(paste(c("GAM", result.GAM[[3]], if(result.GAM[[2]][7]>1 & alert.bimodality) "**"), collapse=" "), sum ((axx>=result.GAM[[2]][2])&(axx<=result.GAM[[2]][3])))); y.labels<-append(y.labels, paste(c("GAM", result.GAM[[3]], if(result.GAM[[2]][7]>1 & alert.bimodality)"**"), collapse=" "))}
       if (methods.incl$HOF>=1)
        {fity.ampl<-append(fity.ampl, result.HOF [[1]][(axx>=result.HOF [[2]][2])&(axx<=result.HOF [[2]][3])]); n.axx.ampl <- append (n.axx.ampl, axx[(axx>=result.HOF [[2]][2])&(axx<=result.HOF [[2]][3])]); y.values.ampl <- append (y.values.ampl, rep (y.labels.ampl, sum ((axx>=result.HOF [[2]][2])&(axx<=result.HOF [[2]][3])))); opt.ampl.y <- append (opt.ampl.y, y.labels.ampl); opt.ampl.x <- append(opt.ampl.x, result.HOF[[2]][1]);  y.labels.ampl <- y.labels.ampl-1; cat.ampl<-append(cat.ampl, rep(paste(c("HOF", result.HOF[[3]], if(result.HOF[[2]][7]>1 & alert.bimodality) "**"), collapse=" "), sum ((axx>=result.HOF[[2]][2])&(axx<=result.HOF[[2]][3])))); y.labels<-append(y.labels, paste(c("HOF", result.HOF[[3]], if(result.HOF[[2]][7]>1 & alert.bimodality)"**"), collapse=" "))}
       }
   
#    if (as.numeric (tclvalue (tk.save.as.pdf))) pdf () else if (as.numeric (tclvalue (tk.open.new.window)) || dev.cur () == 1) windows ()
    if (((dev.cur () == 1) || as.numeric (tclvalue (tk.open.new.window))) &! as.numeric (tclvalue (tk.save.as.pdf))) windows ()
    trellis.device(theme="col.whitebg", new=FALSE)
    if (bw) trellis.par.set(superpose.line = list (col = "black", lty=c(1,2,3,4)), superpose.symbol = list (col = "black")) else trellis.par.set(superpose.line = list (col = c("darkgreen", "red", "royalblue", "black"), lty=1), superpose.symbol = list (col = c("darkgreen", "red", "royalblue", "black")))
    if (draw.interval & bw) trellis.par.set(superpose.line = list (col = c("black"), lty=1))
    
    if (!draw.interval) 
      {
      plot(xyplot (fity~n.axx, groups = cat, main=spec.name.graph, xlab=list(gr.label, cex = 1.25), ylab=list('Probability of occurrence', cex = 1.25), type="a", auto.key = list(space = "right", points = FALSE, lines =  TRUE, columns=1, cex = 1.1, lwd = 2), aspect=1, lwd=5, panel = function (){
              panel.superpose (n.axx, fity, groups = cat, subscripts = TRUE, type = 'l', lwd = 2)
              if (as.numeric (tclvalue (tk.add.rug))) panel.rug (x = jitter (gr[part.species == 0]), regular = T, start = 0.01, end = 0.03, lwd = 1)
              if (as.numeric (tclvalue (tk.add.rug))) panel.rug (x = jitter (gr[part.species == 1]), regular = F, start = 0.97, end = 0.99, lwd = 1)}
              ))
      }
    if (draw.interval) 
      {
      y.values <- NULL
      for (i in seq (length(y.labels), 1)) y.values <- append (y.values, rep(i, 1001))
      plot(xyplot (y.values~n.axx, main = list(spec.name.graph, cex = 1.4), xlab = list(gr.label, cex = 1.25), ylab = NULL, type = 'a', aspect = 0.3, ylim = c(0, length(y.labels)+1), scales = list (y = list (at = seq(1,length(y.labels)), labels=rev(y.labels), tck = 0, cex = 1.25)), panel = function ()
        {
        panel.superpose (n.axx.ampl, y.values.ampl, groups = cat.ampl, subscripts = TRUE, type = 'l', lwd = 3)
        panel.superpose (opt.ampl.x, opt.ampl.y, groups = y.labels, subscripts = TRUE, type = 'p', pch = '|', cex = 2)
                }))
      }}
} # end of for cycle!
if (save.table) write.table (table.result, 'result_table.csv', dec = '.', sep = ';', col.names = NA, row.names = TRUE, qmethod = 'double')

if (names (dev.cur ()) == 'pdf') dev.off ()
}

process2 <-
function(species, gr, spec.name, gr.name, print.graph, save.table, methods.incl, trans.gr, ampl, proportion, auc, save.graph.data, draw.interval, bw, alert.bimodality)
{
species <- species[,order(spec.name)]
spec.name <- sort(spec.name)

axx<-seq(range(gr)[1], range(gr)[2], len=1001)
no.species<-ncol(species)
table.line<-NULL
fity<-NULL
cat<-NULL
fity.ampl<-NULL
n.axx.ampl<-NULL
cat.ampl<-NULL
opt.ampl.x <- NULL
opt.ampl.y <- NULL
y.values.ampl <- NULL

for (sp in seq(1, no.species)) 
  {
  print.GAUS<-NULL
  print.GLM<-NULL
  print.GAM<-NULL
  print.HOF.table<-NULL
  part.species<-trans.to.binom(species[,sp])
  
  if (methods.incl$GAUS==1)
    {
    result.GAUS <- count.GAUS (part.species, gr, axx, ampl, proportion, auc)
    fity<-append(fity, result.GAUS[[1]])
    if (draw.interval)
      {
      fity.ampl<-append(fity.ampl, result.GAUS[[1]][(axx>=result.GAUS[[2]][2])&(axx<=result.GAUS[[2]][3])])
      n.axx.ampl <- append (n.axx.ampl, axx[(axx>=result.GAUS[[2]][2])&(axx<=result.GAUS[[2]][3])])
      cat.ampl<-append(cat.ampl, rep(spec.name[sp], sum((axx>=result.GAUS[[2]][2])&(axx<=result.GAUS[[2]][3]))))
      opt.ampl.x <- append(opt.ampl.x, result.GAUS[[2]][1])
      opt.ampl.y <- append(opt.ampl.y, no.species-sp+1)
      y.values.ampl <- append (y.values.ampl, rep (no.species-sp+1, sum((axx>=result.GAUS[[2]][2])&(axx<=result.GAUS[[2]][3]))))
      }
    table.line <- append(table.line, result.GAUS[[2]])
    } else {
  
  if (methods.incl$GLM>=1)
    {
     result.GLM <- count.GLM (methods.incl.GLM=methods.incl$GLM, part.species, gr, axx, ampl, proportion, auc)
     fity<-append(fity, result.GLM[[1]])
     if (draw.interval)
      {
      fity.ampl<-append(fity.ampl, result.GLM[[1]][(axx>=result.GLM[[2]][2])&(axx<=result.GLM[[2]][3])])
      n.axx.ampl <- append (n.axx.ampl, axx[(axx>=result.GLM[[2]][2])&(axx<=result.GLM[[2]][3])])
      cat.ampl<-append(cat.ampl, rep(spec.name[sp], sum((axx>=result.GLM[[2]][2])&(axx<=result.GLM[[2]][3]))))
      opt.ampl.x <- append(opt.ampl.x, result.GLM[[2]][1])
      opt.ampl.y <- append(opt.ampl.y, no.species-sp+1)
      y.values.ampl <- append (y.values.ampl, rep (no.species-sp+1, sum((axx>=result.GLM[[2]][2])&(axx<=result.GLM[[2]][3]))))
      }
      table.line<-append(table.line, result.GLM[[2]])
      } else {
   
   if (methods.incl$GAM>=1)
      {
      result.GAM <- count.GAM (methods.incl.GAM=methods.incl$GAM, part.species, gr, axx, ampl, proportion, auc)
      fity<-append(fity, result.GAM[[1]])
      if (draw.interval)
       {
       fity.ampl<-append(fity.ampl, result.GAM[[1]][(axx>=result.GAM[[2]][2])&(axx<=result.GAM[[2]][3])])
       n.axx.ampl <- append (n.axx.ampl, axx[(axx>=result.GAM[[2]][2])&(axx<=result.GAM[[2]][3])])
       cat.ampl<-append(cat.ampl, rep(spec.name[sp], sum((axx>=result.GAM[[2]][2])&(axx<=result.GAM[[2]][3]))))
       opt.ampl.x <- append(opt.ampl.x, result.GAM[[2]][1])
       opt.ampl.y <- append(opt.ampl.y, no.species-sp+1)
       y.values.ampl <- append (y.values.ampl, rep (no.species-sp+1, sum((axx>=result.GAM[[2]][2])&(axx<=result.GAM[[2]][3]))))
      
       }
      table.line<-append(table.line, result.GAM[[2]])
      } else {
    
    if (methods.incl$HOF>=1)
      {
      result.HOF <- count.HOF (methods.incl.HOF=methods.incl$HOF, part.species, gr, axx, ampl, proportion, auc)
      fity<-append(fity, result.HOF[[1]])
      if (draw.interval)
        {
        fity.ampl<-append(fity.ampl, result.HOF[[1]][(axx>=result.HOF[[2]][2])&(axx<=result.HOF[[2]][3])])
        n.axx.ampl <- append (n.axx.ampl, axx[(axx>=result.HOF[[2]][2])&(axx<=result.HOF[[2]][3])])
        cat.ampl<-append(cat.ampl, rep(spec.name[sp], sum((axx>=result.HOF[[2]][2])&(axx<=result.HOF[[2]][3]))))
        opt.ampl.x <- append(opt.ampl.x, result.HOF[[2]][1])
        opt.ampl.y <- append(opt.ampl.y, no.species-sp+1)
        y.values.ampl <- append (y.values.ampl, rep (no.species-sp+1, sum((axx>=result.HOF[[2]][2])&(axx<=result.HOF[[2]][3]))))
        }
        table.line<-append(table.line, result.HOF[[2]])
     }}}}}
         
if (save.table==TRUE) {
   table.header<-NULL
  if (methods.incl$GAUS==1){table.header<-append(table.header, c("GAUS - optimum", "GAUS - min", "GAUS - max", "GAUS - prob-optimum", "GAUS - interval", "", "GAUS - bimodality"))}
    else {
    if (methods.incl$GLM>=1){table.header<-append(table.header, c("GLM - optimum", "GLM - min", "GLM - max", "GLM - prob-optimum", "GLM - interval", "GLM - model", "GLM - bimodality"))}
      else {
      if (methods.incl$GAM>=1){table.header<-append(table.header, c("GAM - optimum", "GAM - min", "GAM - max", "GAM - prob-optimum", "GAM - interval", "GAM - model", "GAM - bimodality"))}
        else {
        if (methods.incl$HOF>=1){table.header<-append(table.header, c("HOF - optimum", "HOF - min", "HOF - max", "HOF - prob-optimum", "HOF - interval", "HOF - model", "HOF - bimodality"))}
        }}}
  table.result<-matrix(table.line, nrow=no.species, ncol=7, dimnames=list(spec.name, table.header), byrow=TRUE)
  write.table (table.result, 'result_table.csv', dec = '.', sep = ';', col.names = NA, row.names = TRUE, qmethod = 'double')
  }

if (save.graph.data == TRUE)
  {
  graph.data.matrix <- matrix (c(axx, fity), ncol = no.species+1, nrow = 1001, dimnames = list(seq(1,1001), c(gr.name, spec.name)))  
  write.table (graph.data.matrix, 'graph_data.csv', dec = '.', sep = ';', col.names = TRUE, row.names = FALSE, qmethod = 'double')
    }
    
if (print.graph==TRUE)
    {
    switch (trans.gr+1,
      gr.label<-gr.name,
      gr.label<-paste(c("log (", gr.name, "+1)"), collapse=""),
      gr.label<-paste(c("sqrt (", gr.name, ")"), collapse=""))
    
    graph.title <- c('GAUS', 'GLM', 'GAM', 'HOF')[methods.incl > 0]
    n.axx<-rep(axx, no.species)
    trellis.device(theme="col.whitebg", new=FALSE)
    if (bw & !draw.interval)
      {colors.diagram <- c(rep('black', 6), rep('darkgrey', 6))
       line.types <- c(1,2,3,4,5,6,1,2,3,4,5,6)
       }
    if (!bw)
       {
       colors.diagram <- c('black', 'maroon', 'green', 'navy', 'darkorange', 'purple', 'darkgrey', 'red', 'skyblue', 'darkolivegreen', 'gold', 'blue')
       line.types <- 1
       }
    if (bw & draw.interval)
       {
       colors.diagram <- c("black")
       line.types <- 1
       }
    
    if (as.numeric (tclvalue (tk.save.as.pdf))) pdf () else if (as.numeric (tclvalue (tk.open.new.window))|| dev.cur () == 1) windows ()        
    trellis.par.set (superpose.line = list (col = colors.diagram, lty=line.types), superpose.symbol = list (col = colors.diagram))
    if (draw.interval == FALSE)    
    {
    cat <- NULL
    for (j in seq (1, no.species)) cat<-append(cat, rep(paste(c(spec.name[j], if(table.result[j,7]>1 & alert.bimodality)"**"), collapse = " "), 1001))
    plot(xyplot (fity~n.axx, groups = cat, main=graph.title, xlab=list(gr.label, cex = 1.25), ylab=list('Probability of occurrence', cex = 1.25), type="a", auto.key = list(space = "bottom", points = FALSE, lines =  TRUE, columns=2, size = 3, cex = 1.1), aspect=0.6, lwd = 2))
    }
    if (draw.interval)
    {
    y.values <- NULL
    for (i in seq (no.species, 1)) y.values <- append (y.values, rep(i, 1001))
    key.spec.names <- NULL
    for (j in seq (1, no.species)) key.spec.names <- append (key.spec.names, paste (c(formatC(j, width = 3, format = 'fg', flag = '-'), spec.name[j], if(table.result[j,7]>1 & alert.bimodality)"**"), collapse = ' '))
    plot(xyplot (y.values~n.axx, main = list(graph.title, cex = 1.4), xlab = list(gr.label, cex = 1.25), ylab = NULL, type = 'a', aspect = 0.6, ylim = c(0, no.species+1), scales = list (y = list (at = seq(1, no.species), labels=seq(no.species,1), tck = 0, cex = 1.1)), key = list(space = "bottom", text = list (key.spec.names, col = colors.diagram), columns = 2, cex = 1.2), panel = function ()
        {
        panel.superpose (n.axx.ampl, y.values.ampl, groups = cat.ampl, subscripts = TRUE, type = 'l', lwd = 3)
        panel.superpose (opt.ampl.x, opt.ampl.y, groups = seq(1, no.species), subscripts = TRUE, type = 'p', pch = '|', cex = 2)
        }))
    }
   if (names (dev.cur ()) == 'pdf') dev.off ()
    }
}

process3 <-
function(species, gr, spec.name, gr.name, print.graph, save.table, methods.incl, trans.gr, ampl, proportion, auc, save.graph.data, draw.interval, bw, alert.bimodality)
{
axx<-seq(range(gr)[1], range(gr)[2], len=1001)

table.line<-NULL
print.GAUS<-NULL
print.GLM<-NULL
print.GAM<-NULL
print.HOF.table<-NULL
spec.name<-spec.name[1]

part.species <- trans.to.binom(species)

if (methods.incl$GAUS==1)
    {
    result.GAUS <- count.GAUS (part.species, gr, axx, ampl, proportion, auc)
    }
if (methods.incl$GLM>=1)
    {
  result.GLM <- count.GLM (methods.incl.GLM=methods.incl$GLM, part.species, gr, axx, ampl, proportion, auc)
    }
if (methods.incl$GAM>=1)
   {
  result.GAM <- count.GAM (methods.incl.GAM=methods.incl$GAM, part.species, gr, axx, ampl, proportion, auc)
   }
if (methods.incl$HOF>=1)
    {
  result.HOF <- count.HOF (methods.incl.HOF=methods.incl$HOF, part.species, gr, axx, ampl, proportion, auc)
      }

if (save.table==TRUE)
   {
    if (methods.incl$GAUS==1) {table.line<-append(table.line, c(result.GAUS[[2]]))}
    if (methods.incl$GLM>=1)  {table.line<-append(table.line, c(result.GLM[[2]]))}
    if (methods.incl$GAM>=1)  {table.line<-append(table.line, c(result.GAM[[2]]))}
    if (methods.incl$HOF>=1)  {table.line<-append(table.line, c(result.HOF[[2]]))}
    table.header<-NULL
    if (methods.incl$GAUS==1){table.header<-append(table.header, c("GAUS - optimum", "GAUS - min", "GAUS - max", "GAUS - prob-optimum", "GAUS - interval", "", "GAUS - bimodality"))}
    if (methods.incl$GLM>=1){table.header<-append(table.header, c("GLM - optimum", "GLM - min", "GLM - max", "GLM - prob-optimum", "GLM - interval", "GLM - model", "GLM - bimodality"))}
    if (methods.incl$GAM>=1){table.header<-append(table.header, c("GAM - optimum", "GAM - min", "GAM - max", "GAM - prob-optimum", "GAM - interval", "GAM - model", "GAM - bimodality"))}
    if (methods.incl$HOF>=1){table.header<-append(table.header, c("HOF - optimum", "HOF - min", "HOF - max", "HOF - prob-optimum", "HOF - interval", "HOF - model", "HOF - bimodality"))}
    table.no.col<-(trans.to.binom(methods.incl$GAUS) + trans.to.binom(methods.incl$GLM) + trans.to.binom(methods.incl$GAM) + trans.to.binom(methods.incl$HOF))*7
    table.result<-matrix(table.line, nrow=1, ncol=table.no.col, dimnames=list(spec.name, table.header), byrow=TRUE)
  } 
  table.result
}

remove.bellow.zerro <-
function (bl)
{
bl[bl < 0] <- NA
bl
}

trans.to.binom <-
function(x)
  {as.numeric (x > 0)}

#######################
sort.species <- function ()
{
if (tclvalue (sort.by) == 'alph')
  {
  assign ('sp.not.use.1', env = .GlobalEnv, sp.not.use.1[order (sp.not.use.1$orig.name),])
  assign ('sp.to.use.1', env = .GlobalEnv, sp.to.use.1[order (sp.to.use.1$orig.name),])
  }
if (tclvalue (sort.by) == 'freq')
  {
  assign ('sp.not.use.1', env = .GlobalEnv, sp.not.use.1[rev (order (sp.not.use.1$freq)),])
  assign ('sp.to.use.1', env = .GlobalEnv, sp.to.use.1[rev (order (sp.to.use.1$freq)),])
  }
if (tclvalue (sort.by) == 'spd')
  {
  assign ('sp.not.use.1', env = .GlobalEnv, sp.not.use.1[order (sp.not.use.1$sp.dat),])
  assign ('sp.to.use.1', env = .GlobalEnv, sp.to.use.1[order (sp.to.use.1$sp.dat),])
  }
if (tclvalue (sort.by) == 'order')
  {
  assign ('sp.not.use.1', env = .GlobalEnv, sp.not.use.1[order (sp.not.use.1$table.order),])
  assign ('sp.to.use.1', env = .GlobalEnv, sp.to.use.1[order (sp.to.use.1$table.order),])
  }
}   


select.species.button <- function () 
{
delete.listbox <- function ()
   {
   tkdelete (sel.species.lb1, 0, length (sp.not.use.1$display)-1)
   tkdelete (sel.species.lb2, 0, length (sp.to.use.1$display)-1)
   }
list.listbox <- function ()
   {
   lapply (rev (as.character (sp.not.use.1$display)), FUN = function (x) tkinsert (sel.species.lb1, 0, x))
   lapply (rev (as.character (sp.to.use.1$display)), FUN = function (x) tkinsert (sel.species.lb2, 0, x))
   }

  sel1.base <- tktoplevel ()
  sel.species <- tkframe (sel1.base)
  sel.species.listbox.1 <- tkframe (sel.species)
  sel.species.listbox.2 <- tkframe (sel.species)
  sel.species.buttons <- tkframe (sel.species)
  tkwm.title (sel1.base, 'Select the species for calculation of SRC')

  sel.species.sc1 <- tkscrollbar (sel.species.listbox.1, command = function (...) tkyview (sel.species.lb1,...))
  sel.species.lb1 <- tklistbox (sel.species.listbox.1, state = 'normal', activestyle = 'none', selectmode = 'extended', width = 50, exportselection = F, yscrollcommand = function (...) tkset(sel.species.sc1, ...))
  lapply (rev (as.character (sp.not.use.1$display)), FUN = function (x) tkinsert (sel.species.lb1, 0, x))
  tkpack (tklabel (sel.species.listbox.1, text = 'List of species:'))
  tkpack (sel.species.lb1, side = 'left', expand = T, fill = 'both')
  tkpack (sel.species.sc1, side = 'right', fill = 'y')
 # tkpack (sel.species.listbox.1, padx = 10, pady = 10, side = 'left')

  sel.species.sc2 <- tkscrollbar (sel.species.listbox.2, command = function (...) tkyview (sel.species.lb2,...))
  sel.species.lb2 <- tklistbox (sel.species.listbox.2, state = 'normal', activestyle = 'none', selectmode = 'extended', width = 50, exportselection = F, yscrollcommand = function (...) tkset(sel.species.sc2, ...))
  lapply (rev (as.character (sp.to.use.1$display)), FUN = function (x) tkinsert (sel.species.lb2, 0, x))
  tkpack (tklabel (sel.species.listbox.2, text = 'Species to be used:'))
  tkpack (sel.species.lb2, side = 'left', expand = T, fill = 'both')
  tkpack (sel.species.sc2, side = 'right', fill = 'y')
#  tkpack (sel.species.listbox.2, padx = 10, pady = 10, side = 'right')
  
  tkpack (tkbutton (sel.species.buttons, text = '>>', command = function (...) {
    if (length (as.numeric (tkcurselection (sel.species.lb1))) > 0) 
    {
    cursel.lb1 <- as.numeric (tkcurselection (sel.species.lb1))+1
    delete.listbox ()
    assign ('sp.to.use.1', env = .GlobalEnv, rbind (sp.to.use.1, sp.not.use.1[cursel.lb1,]))
    assign ('sp.not.use.1', env = .GlobalEnv, sp.not.use.1[-cursel.lb1,])
    sort.species ()
    list.listbox ()
    }}))
    
  tkpack (tkbutton (sel.species.buttons, text = '<<', command = function () {
  if (length (as.numeric (tkcurselection (sel.species.lb2))) > 0) 
    {
    cursel.lb2 <- as.numeric (tkcurselection (sel.species.lb2))+1
    delete.listbox ()
    assign ('sp.not.use.1', env = .GlobalEnv, rbind (sp.not.use.1, sp.to.use.1[cursel.lb2,]))
    assign ('sp.to.use.1', env = .GlobalEnv, sp.to.use.1[-cursel.lb2,])
    sort.species ()
    list.listbox ()
    }}))
  tkpack (sel.species.listbox.1, sel.species.buttons, sel.species.listbox.2, side = 'left', padx = 10, pady = 10)
  tkpack (sel.species)
  
  sel1.radio <- tkframe (sel1.base)
  tkpack (tklabel (sel1.radio, text = 'Sort species by '),
    tkradiobutton (sel1.radio, text = 'alphabet ', var = sort.by, value = 'alph', command = function () {sort.species(); delete.listbox (); list.listbox ()}),
    tkradiobutton (sel1.radio, text = 'frequency ', var = sort.by, value = 'freq', command = function () {sort.species(); delete.listbox (); list.listbox ()}),
    tkradiobutton (sel1.radio, text = 'species data ', var = sort.by, value = 'spd', command = function () {sort.species(); delete.listbox (); list.listbox ()}),
    tkradiobutton (sel1.radio, text = 'order in original table ', var = sort.by, value = 'order', command = function () {sort.species(); delete.listbox (); list.listbox ()}),
    anchor = 'w', side = 'left'
    )
    
  tkpack (sel1.radio) 
  tkpack (tkbutton (sel1.base, text = 'Ok', command = function () tkdestroy (sel1.base)), side = 'right', padx = 10, pady = 10)
}

calculate <- function () 
{
input.data <- as.data.frame (cbind (JUICE.short.head$Short_Head, JUICE.table[,as.character (sp.to.use.1$orig.name)]))
colnames (input.data) <- c (tclvalue (gr.name), as.character (sp.to.use.1$orig.name))
print.result(input.data = input.data, type.of.mode=as.numeric (tclvalue (tk.type.of.mode)), print.graph=TRUE, save.table=TRUE, GAUS = switch (as.numeric (tclvalue (tk.type.of.mode)), 
  if (tclvalue (tk.GAUS.one) == '1') 1 else 0,
  if (tclvalue (tk.method.group) == 'Gauss') 1 else 0,
  if (tclvalue (tk.method.all) == 'Gauss') 1 else 0),
 GLM=switch (as.numeric (tclvalue (tk.type.of.mode)), 
  if (tclvalue (tk.GLM.one) == '1') as.numeric (tclvalue (tk.GLM.model)) else 0,
  if (tclvalue (tk.method.group) == 'GLM') as.numeric (tclvalue (tk.GLM.model)) else 0,
  if (tclvalue (tk.method.all) == 'GLM') as.numeric (tclvalue (tk.GLM.model)) else 0),
 GAM=switch (as.numeric (tclvalue (tk.type.of.mode)), 
  if (tclvalue (tk.GAM.one) == '1') as.numeric (tclvalue (tk.GAM.model)) else 0,
  if (tclvalue (tk.method.group) == 'GAM') as.numeric (tclvalue (tk.GAM.model)) else 0,
  if (tclvalue (tk.method.all) == 'GAM') as.numeric (tclvalue (tk.GAM.model)) else 0),
 HOF=switch (as.numeric (tclvalue (tk.type.of.mode)), 
  if (tclvalue (tk.HOF.one) == '1') as.numeric (tclvalue (tk.HOF.model)) else 0,
  if (tclvalue (tk.method.group) == 'HOF') as.numeric (tclvalue (tk.HOF.model)) else 0,
  if (tclvalue (tk.method.all) == 'HOF') as.numeric (tclvalue (tk.HOF.model)) else 0),
 trans.gr=as.numeric (tclvalue (tk.trans.gr)), ampl=tclvalue (tk.ampl), proportion=as.numeric (tclvalue (tk.proportion)), auc = as.numeric (tclvalue (tk.auc)), save.graph.data = as.logical (as.numeric(tclvalue (tk.save.graph.data))), draw.interval = as.logical (as.numeric(tclvalue (tk.draw.interval))), bw = as.logical (as.numeric( tclvalue (tk.bw))), alert.bimodality = as.logical (as.numeric(tclvalue (tk.alert.bimodality))))
}

disable.able.fr345 <- function (fr3 = 'normal', fr4 = 'disabled', fr5 = 'disabled')
{
tkconfigure (fl3.but, state = fr3)
tkconfigure (fl3.check1, state = fr3)
tkconfigure (fl3.check2, state = fr3)
tkconfigure (fl3.check3, state = fr3)
tkconfigure (fl3.check4, state = fr3)

tkconfigure (fl4.but, state = fr4)
tkconfigure (fl4.radio1, state = fr4)
tkconfigure (fl4.radio2, state = fr4)
tkconfigure (fl4.radio3, state = fr4)
tkconfigure (fl4.radio4, state = fr4)

tkconfigure (fl5.radio1, state = fr5)
tkconfigure (fl5.radio2, state = fr5)
tkconfigure (fl5.radio3, state = fr5)
tkconfigure (fl5.radio4, state = fr5)
tkconfigure (fl5.radio5, state = fr5)
tkconfigure (fl5.radio6, state = fr5)
tkconfigure (fl5.radio7, state = fr5)
tkconfigure (fl5.radio8, state = fr5)
tkconfigure (fl5.radio9, state = fr5)
}

lib.admin <- function ()
{
cancel.admin<- tclVar (0)

sub.lib.admin <- function ()
{
inst.pack <- installed.packages()[,1]
admin <- tktoplevel ()
tkwm.title (admin, 'Installed libraries')
admin.1 <- tkframe (admin)
admin.2 <- tkframe (admin)
admin.3 <- tkframe (admin)
admin.4 <- tkframe (admin)
tkpack (tklabel (admin, text = 'Administration of R packages'))
gravy.button <- tkbutton (admin.1, width = 10, text = 'Install gravy', command = function () 
  if (as.numeric (R.version$minor) >= 12 & as.numeric (R.version$major) >= 2)
    {install.packages ('gravy', contriburl =  'http://sci.muni.cz/botany/zeleny/R/windows/contrib/R-2.12/'); library (gravy); tkdestroy (admin); sub.lib.admin ()} else if (as.numeric (R.version$minor) <= 9 & as.numeric (R.version$major) == 2) {install.packages ('gravy', contriburl = 'http://sci.muni.cz/botany/zeleny/R/windows/contrib/R-2.1.0/'); library (gravy); tkdestroy (admin); sub.lib.admin ()} else 
    winDialog (paste ('R library gravy cannot be installed - it is available only for R versions <= 2.9 and >= 2.12. Your R version is ', R.version$major, '.', R.version$minor , '. Try to use newer R version.', sep = ''), type = 'ok'))
tkconfigure (gravy.button, state = if ('gravy' %in% installed.packages()[,1]) 'disabled' else 'normal')
tkpack (tklabel (admin.1, width = 20, text = paste ('gravy is', if (!'gravy' %in% inst.pack) 'not', 'installed')), gravy.button, side = 'right', anchor = 'w', side = 'left')

tcltk.button <- tkbutton (admin.2, width = 10, text = 'Install tcltk', command = function () {install.packages ('tcltk'); library (tcltk); tkdestroy (admin); sub.lib.admin ()})
tkconfigure (tcltk.button, state = if ('tcltk' %in% installed.packages()[,1]) 'disabled' else 'normal')
tkpack (tklabel (admin.2, width = 20, text = paste ('tcltk is', if (!'tcltk' %in% inst.pack) 'not', 'installed')), tcltk.button, side = 'left', anchor = 'w')

mgcv.button <- tkbutton (admin.3, width = 10, text = 'Install mgcv', command = function () {install.packages ('mgcv'); library (mgcv); tkdestroy (admin); sub.lib.admin ()})
tkconfigure (mgcv.button, state = if ('mgcv' %in% installed.packages()[,1]) 'disabled' else 'normal')
tkpack (tklabel (admin.3, width = 20, text = paste ('mgcv is', if (!'tcltk' %in% inst.pack) 'not', 'installed')), mgcv.button, side = 'left', anchor = 'w')

lattice.button <- tkbutton (admin.4, width = 10, text = 'Install lattice', command = function () {install.packages ('lattice'); library (lattice); tkdestroy (admin); sub.lib.admin ()})
tkconfigure (lattice.button, state = if ('lattice' %in% installed.packages()[,1]) 'disabled' else 'normal')
tkpack (tklabel (admin.4, width = 20, text = paste ('lattice is', if (!'lattice' %in% inst.pack) 'not', 'installed')), lattice.button, side = 'left', anchor = 'w')
tkpack (admin.1, admin.2, admin.3, admin.4, anchor = 'w')
tkbind (admin, '<Destroy>', function() {tclvalue(cancel.admin)<-1; tkdestroy (admin)})
}
sub.lib.admin ()
tkwait.variable (cancel.admin)
}
################
# THE START
if (!all (require (tcltk),require (lattice), require (mgcv), require (gravy))) lib.admin ()

cancel <- tclVar (0)


sp.names <- names (JUICE.table)
sp.names.table <- as.data.frame (list (orig.name = colnames (JUICE.table), sp.name = unlist (lapply (strsplit (colnames (JUICE.table), '_'), function (x) x[[1]])), layer = JUICE.species.data$Layer, freq = colSums (JUICE.table>0), sp.data = JUICE.species.data$Species_Data, table.order = seq (1, dim (JUICE.table)[2])))
sp.names.table <- cbind (sp.names.table, display = apply (sp.names.table, 1, FUN = function (x) paste ('[', formatC (x[4], width = length (unlist(strsplit (as.character (max (sp.names.table$freq)), split = '')))), '] [', formatC (x[5], width = max (unlist (lapply (strsplit (as.character (sp.names.table$sp.data), split = ''), length)))), '] [', x[3],'] ', x[2], sep = '')))

sp.to.use.1 <- sp.names.table[0,]
rownames (sp.to.use.1) <- NULL
sp.not.use.1 <- sp.names.table
rownames (sp.not.use.1) <- seq (1, dim (sp.not.use.1)[1])

sort.by.alph <- tclVar (0)
sort.by.freq <- tclVar (0)
sort.by.spd <- tclVar (0)
sort.by.order <- tclVar (1)
sort.by <- tclVar ('alph')

base <- tktoplevel ()
frame.up <- tkframe (base, borderwidth = 10)
frame.down <- tkframe (base, borderwidth = 10)
frame.left <- tkframe (frame.up)
frame.left.1 <- tkframe (frame.left, relief= 'groove', borderwidth=2)
frame.left.2 <- tkframe (frame.left, relief= 'groove', borderwidth=2)
frame.left.3 <- tkframe (frame.left, relief= 'groove', borderwidth=2)
frame.left.4 <- tkframe (frame.left, relief= 'groove', borderwidth=2)
frame.left.5 <- tkframe (frame.left, relief= 'groove', borderwidth=2)

frame.right <- tkframe (frame.up)
frame.right.1 <- tkframe (frame.right, relief= 'groove', borderwidth=2)
frame.right.2 <- tkframe (frame.right, relief= 'groove', borderwidth=2)
frame.right.3 <- tkframe (frame.right, relief= 'groove', borderwidth=2)
frame.right.4 <- tkframe (frame.right, relief= 'groove', borderwidth=2)
frame.right.5 <- tkframe (frame.right, relief= 'groove', borderwidth=2)

# frame.left.1
gr.name <- tclVar ('GRADIENT')
tkpack (tklabel (frame.left.1, text = 'Name of the gradient to be used in the figure'), tkentry (frame.left.1, textvariable = gr.name, width = 30), anchor = 'w')

# frame.left.2
tk.trans.gr <- tclVar (0)
tkpack (tklabel (frame.left.2, text = 'Transformation of environmental variable'), anchor = 'w')
tkpack (tkradiobutton (frame.left.2, text = 'none', var = tk.trans.gr, value = 0),
tkradiobutton (frame.left.2, text = 'log', var = tk.trans.gr, value = 1),
tkradiobutton (frame.left.2, text = 'square root', var = tk.trans.gr, value = 2),
anchor = 'w', side = 'left')

# frame.left.3
tk.type.of.mode <- tclVar (1)
tk.GAUS.one <- tclVar (1)
tk.GLM.one <- tclVar (1)
tk.GAM.one <- tclVar (1)
tk.HOF.one <- tclVar (1)

tkpack (tkradiobutton (frame.left.3, text = 'Analyse only one species', var = tk.type.of.mode, value = 1, command = function () disable.able.fr345 ('normal', 'disabled', 'disabled')), anchor = 'w')
fl3.but <- tkbutton (frame.left.3, text = 'Select species', command = function () select.species.button ())
fl3.check1 <- tkcheckbutton (frame.left.3, text = 'Gauss', var = tk.GAUS.one)
fl3.check2 <- tkcheckbutton (frame.left.3, text = 'GLM', var = tk.GLM.one)
fl3.check3 <- tkcheckbutton (frame.left.3, text = 'GAM', var = tk.GAM.one)
fl3.check4 <- tkcheckbutton (frame.left.3, text = 'HOF', var = tk.HOF.one)
tkpack (fl3.but, anchor = 'w')
tkpack (tklabel (frame.left.3, text = 'Select model: '), fl3.check1, fl3.check2, fl3.check3, fl3.check4, anchor = 'w', side = 'left')

# frame.left.4
tk.method.group <- tclVar ('Gauss')
fl4.but <- tkbutton (frame.left.4, text = 'Select species', command = function () select.species.button ())
fl4.radio1 <- tkradiobutton (frame.left.4, text = 'Gauss', var = tk.method.group, value = 'Gauss')
fl4.radio2 <- tkradiobutton (frame.left.4, text = 'GLM', var = tk.method.group, value = 'GLM')
fl4.radio3 <- tkradiobutton (frame.left.4, text = 'GAM', var = tk.method.group, value = 'GAM')
fl4.radio4 <- tkradiobutton (frame.left.4, text = 'HOF', var = tk.method.group, value = 'HOF')
tkpack (tkradiobutton (frame.left.4, text = 'Analyse group of species', var = tk.type.of.mode, value = 2, command = function () disable.able.fr345 ('disabled', 'normal', 'disabled')), anchor = 'w')
tkpack (fl4.but, anchor = 'w')
tkpack (tklabel (frame.left.4, text = 'Select model: '),  fl4.radio1, fl4.radio2, fl4.radio3, fl4.radio4, anchor = 'w', side = 'left')


# frame.left.5
tk.method.all <- tclVar ('Gauss')
tkpack (tkradiobutton (frame.left.5, text = 'Analyse all species', var = tk.type.of.mode, value = 3, command = function () disable.able.fr345 ('disabled', 'disabled', 'normal')), anchor = 'w')
frame.left.5.1 <- tkframe (frame.left.5)
frame.left.5.2 <- tkframe (frame.left.5)

fl5.radio1 <- tkradiobutton (frame.left.5.1, text = 'Gauss', var = tk.method.all, value = 'Gauss')
fl5.radio2 <- tkradiobutton (frame.left.5.1, text = 'GLM', var = tk.method.all, value = 'GLM')
fl5.radio3 <- tkradiobutton (frame.left.5.1, text = 'GAM', var = tk.method.all, value = 'GAM')
fl5.radio4 <- tkradiobutton (frame.left.5.1, text = 'HOF', var = tk.method.all, value = 'HOF')
tkpack (tklabel (frame.left.5.1, text = 'Select model: '), fl5.radio1, fl5.radio2, fl5.radio3, fl5.radio4, anchor = 'w', side = 'left')

tk.save.sp.data <- tclVar (1)
fl5.radio5 <- tkradiobutton (frame.left.5.2, text = 'optimum', var = tk.save.sp.data, value = 1)
fl5.radio6 <- tkradiobutton (frame.left.5.2, text = 'min', var = tk.save.sp.data, value = 2)
fl5.radio7 <- tkradiobutton (frame.left.5.2, text = 'max', var = tk.save.sp.data, value = 3)
fl5.radio8 <- tkradiobutton (frame.left.5.2, text = 'range', var = tk.save.sp.data, value = 5) # the values 5 and 4 are interchanged - it takes into consideradion the order in output file
fl5.radio9 <- tkradiobutton (frame.left.5.2, text = 'optimum prob.', var = tk.save.sp.data, value = 4)

tkpack (tklabel (frame.left.5.2, text = 'Create file for import to JUICE species data:'), anchor = 'w')
tkpack (fl5.radio5, fl5.radio6, fl5.radio7, fl5.radio8, fl5.radio9, anchor = 'w', side = 'left')
tkpack (frame.left.5.1, frame.left.5.2, anchor = 'w')

disable.able.fr345 ('normal', 'disabled', 'disabled')

# frame.right.1
tk.ampl <- tclVar ('ratio')
tk.proportion <- tclVar (0.5)
tk.auc <- tclVar (80)
frame.right.1.1 <- tkframe (frame.right.1)
frame.right.1.2 <- tkframe (frame.right.1)
fr1.radio1 <- tkradiobutton (frame.right.1.1, text = 'Ratio from maximum: ', var = tk.ampl, value = 'ratio')
fr1.radio2 <- tkradiobutton (frame.right.1.2, text = 'Area under curve [%]: ', var = tk.ampl, value = 'area')
fr1.entry1 <- tkentry (frame.right.1.1, textvariable = tk.proportion, width = 5)
fr1.entry2 <- tkentry (frame.right.1.2, textvariable = tk.auc, width = 5)
tkpack (tklabel (frame.right.1, text = 'Method of interval calculation'), anchor = 'w')
tkpack (fr1.radio1, fr1.entry1, anchor = 'w', side = 'left')
tkpack (fr1.radio2, fr1.entry2, anchor = 'w', side = 'left')
tkpack (frame.right.1.1, frame.right.1.2, anchor = 'w')

# frame.right.2
tk.draw.interval <- tclVar (0)
tk.save.as.pdf <- tclVar (0)
tk.save.graph.data <- tclVar (0)
tk.bw <- tclVar (0)
tk.alert.bimodality <- tclVar (0)
tk.open.new.window <- tclVar (0)
tk.add.rug <- tclVar (0)
frame.right.2.1 <- tkframe (frame.right.2)
frame.right.2.2 <- tkframe (frame.right.2)
fr2.radio1 <- tkradiobutton (frame.right.2.1, text = 'curves', var = tk.draw.interval, value = 0)
fr2.radio2 <- tkradiobutton (frame.right.2.1, text = 'optima intervals', var = tk.draw.interval, value = 1)
fr2.radio3 <- tkradiobutton (frame.right.2.2, text = 'on screen', var = tk.save.as.pdf, value = 0)
fr2.radio4 <- tkradiobutton (frame.right.2.2, text = 'as pdf', var = tk.save.as.pdf, value = 1)
fr2.check1 <- tkcheckbutton (frame.right.2, text = 'export graph data to csv format', var = tk.save.graph.data)
fr2.check2 <- tkcheckbutton (frame.right.2, text = 'black and white graphs', var = tk.bw)
fr2.check3 <- tkcheckbutton (frame.right.2, text = 'alert bimodality of the curve', var = tk.alert.bimodality)
fr2.check4 <- tkcheckbutton (frame.right.2, text = 'each figure in a new window', var = tk.open.new.window)
fr2.check5 <- tkcheckbutton (frame.right.2, text = 'add data points as rug to the figure', var = tk.add.rug)
tkpack (tklabel (frame.right.2, text = 'Format of the figure and export'), anchor = 'w')
tkpack (tklabel (frame.right.2.1, text = 'Figure: '), fr2.radio1, fr2.radio2, anchor = 'w', side = 'left')
tkpack (tklabel (frame.right.2.2, text = 'Draw figure as: '), fr2.radio3, fr2.radio4, anchor = 'w', side = 'left')
tkpack (frame.right.2.1, frame.right.2.2, fr2.check1, fr2.check2, fr2.check3, fr2.check4,fr2.check5, anchor = 'w')

# frame.right.3
tk.HOF.model <- tclVar (1)
frame.right.3.1 <- tkframe (frame.right.3)
fr3.radio1 <- tkradiobutton (frame.right.3, text = 'automatic selection', var = tk.HOF.model, value = 1)
fr3.radio2 <- tkradiobutton (frame.right.3.1, text = 'I', var = tk.HOF.model, value = 11)
fr3.radio3 <- tkradiobutton (frame.right.3.1, text = 'II', var = tk.HOF.model, value = 12)
fr3.radio4 <- tkradiobutton (frame.right.3.1, text = 'III', var = tk.HOF.model, value = 13)
fr3.radio5 <- tkradiobutton (frame.right.3.1, text = 'IV', var = tk.HOF.model, value = 14)
fr3.radio6 <- tkradiobutton (frame.right.3.1, text = 'V', var = tk.HOF.model, value = 15)

tkpack (tklabel (frame.right.3, text = 'HOF models:'), fr3.radio1, anchor = 'w') 
tkpack (tklabel (frame.right.3.1, text = 'HOF model '), fr3.radio2, fr3.radio3, fr3.radio4, fr3.radio5, fr3.radio6, anchor = 'w', side = 'left')
tkpack (frame.right.3.1)

# frame.right.4
tk.GLM.model <- tclVar (1)
frame.right.4.1 <- tkframe (frame.right.4)
fr4.radio1 <- tkradiobutton (frame.right.4, text = 'automatic selection', var = tk.GLM.model, value = 1)
fr4.radio2 <- tkradiobutton (frame.right.4.1, text = '1 ', var = tk.GLM.model, value = 11)
fr4.radio3 <- tkradiobutton (frame.right.4.1, text = '2 ', var = tk.GLM.model, value = 12)
fr4.radio4 <- tkradiobutton (frame.right.4.1, text = '3 ', var = tk.GLM.model, value = 13)
tkpack (tklabel (frame.right.4, text = 'GLM models:'), fr4.radio1, anchor = 'w')
tkpack (tklabel (frame.right.4.1, text = 'order of polynom: '), fr4.radio2, fr4.radio3, fr4.radio4, anchor = 'w', side = 'left')
tkpack (frame.right.4.1)

# frame.right.5
tk.GAM.model <- tclVar (1)
frame.right.5.1 <- tkframe (frame.right.5)
fr5.radio1 <- tkradiobutton (frame.right.5, text = 'automatic selection', var = tk.GAM.model, value = 1)
fr5.radio2 <- tkradiobutton (frame.right.5.1, text = '3 ', var = tk.GAM.model, value = 13)
fr5.radio3 <- tkradiobutton (frame.right.5.1, text = '4 ', var = tk.GAM.model, value = 14)
fr5.radio4 <- tkradiobutton (frame.right.5.1, text = '5 ', var = tk.GAM.model, value = 15)
tkpack (tklabel (frame.right.5, text = 'GAM models:'), fr5.radio1, anchor = 'w')
tkpack (tklabel (frame.right.5.1, text = 'degree of freedom: '), fr5.radio2, fr5.radio3, fr5.radio4, anchor = 'w', side = 'left')
tkpack (frame.right.5.1)

# frame.down
tkpack (
  tkbutton (frame.down, text = 'Calculate', width = 12, command = function () calculate ()),
  tkbutton (frame.down, text = 'Cancel', width = 12, command = function () {tkdestroy (base); tclvalue (cancel) <- 1 }), 
  tkbutton (frame.down, text = 'Online help', width = 12, command = function () browseURL ('http://www.sci.muni.cz/botany/zeleny/hof.php')),
  tkbutton (frame.down, text = 'Open result file', width = 16, command = function () try(shell.exec (paste (getwd(), '/result_table.csv', sep = '')))),
  tkbutton (frame.down, text = 'Open pdf', width = 12, command = function () try (shell.exec (paste (getwd (), '/Rplots.pdf', sep = '')))),
  tkbutton (frame.down, text = 'R library admin', width = 16, command = function () lib.admin ())
    , anchor = 'e', side = 'right')

windows ()
tkpack (frame.left.1, frame.left.2, frame.left.3, frame.left.4, frame.left.5, expand = T, fill = 'both')
tkpack (frame.right.1, frame.right.2, frame.right.3, frame.right.4, frame.right.5, expand = T, fill = 'both')
tkpack (frame.left, frame.right, side = 'left', expand = T, fill = 'y')
tkpack (frame.up, frame.down, expand = T, fill = 'both')
tkbind (base, '<Destroy>', function() tclvalue(cancel)<-2)
tkraise (base)


tkwait.variable (cancel)